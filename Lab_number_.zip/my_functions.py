# ScriptName: my_functions.py
# Author: <add your name here>

# template for calling functions in another file


def print_function():
    print("I'm in another file :)")